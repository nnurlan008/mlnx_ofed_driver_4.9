#! /bin/bash
# SPDX-License-Identifier: BSD-3-Clause

. ${DIR}/tun_aesgcm_defs.sh

SGW_CMD_XPRM=
