#! /bin/bash
# SPDX-License-Identifier: BSD-3-Clause

. ${DIR}/trs_aesctr_sha1_defs.sh

SGW_CMD_XPRM=
