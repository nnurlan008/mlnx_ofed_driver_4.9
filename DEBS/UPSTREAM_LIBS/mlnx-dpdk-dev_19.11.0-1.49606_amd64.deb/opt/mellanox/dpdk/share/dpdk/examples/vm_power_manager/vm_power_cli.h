/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2014 Intel Corporation
 */

#ifndef VM_POWER_CLI_H_
#define VM_POWER_CLI_H_

#ifdef __cplusplus
extern "C" {
#endif

void run_cli(__attribute__((unused)) void *arg);

#ifdef __cplusplus
}
#endif

#endif /* VM_POWER_CLI_H_ */
