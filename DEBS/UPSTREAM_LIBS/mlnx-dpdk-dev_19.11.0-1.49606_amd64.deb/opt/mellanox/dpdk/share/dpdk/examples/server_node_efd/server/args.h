/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2016-2017 Intel Corporation
 */

#ifndef _ARGS_H_
#define _ARGS_H_

int parse_app_args(uint8_t max_ports, int argc, char *argv[]);

#endif /* ifndef _ARGS_H_ */
