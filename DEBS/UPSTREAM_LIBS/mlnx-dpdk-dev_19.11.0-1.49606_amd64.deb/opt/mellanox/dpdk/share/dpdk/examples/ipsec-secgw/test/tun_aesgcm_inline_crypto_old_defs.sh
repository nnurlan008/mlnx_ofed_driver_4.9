#! /bin/bash
# SPDX-License-Identifier: BSD-3-Clause

. ${DIR}/tun_aesgcm_inline_crypto_defs.sh

SGW_CMD_XPRM=
