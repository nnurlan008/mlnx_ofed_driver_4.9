#! /bin/bash

. ${DIR}/tun_aesgcm_defs.sh

SGW_CFG_XPRM_IN='port_id 0 type inline-crypto-offload fallback lookaside-none'
