#! /bin/bash
# SPDX-License-Identifier: BSD-3-Clause

. ${DIR}/trs_aesgcm_inline_crypto_defs.sh

SGW_CMD_XPRM=
