#! /bin/bash
# SPDX-License-Identifier: BSD-3-Clause

. ${DIR}/trs_aesctr_sha1_esn_defs.sh

SGW_CMD_XPRM='-e -a -w 300 -l'
