#  IBUTILS2 release notes

&copy; Copyright 2019, Mellanox Technologies, Inc. All Rights Reserved.


## IBUTILS 2.3.0

### Version details:

Release date: February 2020


### Features:

- ibdiagnet: Support Fabric Summary Table.
- ibdiagnet: Support Congestion Control configuration MADs.
- ibdiagnet: Add switch ports pkeys to the PKey file and CSV.
- ibdiagnet: Add support for Aggregation Node Active Jobs MAD.
- ibdiagnet: Add additional counters of Port Counters Extended to CSV and PM files.
- ibdiagnet: Add support for SHARP V2.


### Fixes:

- ibdiagnet: Fix gcc 9.2.1 warnings.
- ibdiagnet: Handle invalid LIDs on virtual port and switch port 0.
- ibdiagnet: Remove duplicated lines from pkeys section in csv.


### Changes:

- ibdianget: Add documentation for ibdiagnet scope feature.
- ibdiagnet: Add new flag to support specific version in sharp stage.
- ibdiagnet: Fix ibdiagnet_csv2xml.py to support Python 2 and Python 3.


## IBUTILS 2.2.1

### Version details:

Release date: November 2019


### Features:

- ibdiagnet: Support dumping virtual ports QoS information.
- ibdiagnet: Support generating configuration file.


### Fixes:

- ibdiagnet: Fix array overflow in credit loop check.
- ibis: fix compilation on xenserver6u5
- phy_diag_plugin: Fix segmentation fault in PCI plugin.
- phy_diag_plugin: Mark only the special port as not support DD.


### Changes:

- ibdiagnet: Prefer plugins from env variable IBDIAGNET_PLUGINS_PATH if set.
- ibdiagnet: Set 'N/A' for down ports for MTU, LWA, LSA in net_dump and net_dump_ext.
- ibdiagnet: Avoid writing log to default location if output_path option on.


## IBUTILS 2.2.0

### Version details:

Release date: September 2019


### Features:

- ibdiagnet: Collect Adaptive routing tables by default during routing stage.
- ibdiagnet: Support new threshold parameters for FW calculated BER counters:
  - ber_thresh_error &lt;thresh&gt;  : set threshold for ber errors (default=1e-8)
  - ber_thresh_warning &lt;thresh&gt; : set threshold for ber warnings (default=1e-13)
- phy_diag_plugin: Support new cable info fields:
  - CDR Latched TX/RX Loss Indicator
  - Latched Adaptive Equalization Fault
  - Latched  TX / RX LOL Indicator
  - Latched Temperature Alarm and Warning
  - Latched Voltage Alarm and Warning
  - RX Power Alarm and Warning
  - TX Bias Alarm and Warning
  - TX Power Alarm and Warning
  - Supply Voltage Reporting
  - Transmitter Technology
  - Extended Specification Compliance Codes
  - DateCode
  - Lot
  - TX Adaptive Equalization Freeze
  - RX Output Disable
  - TX Adaptive Equalization Enable
- phy_diag_plugin: Send MPEIN register based on device DPN.
- phy_diag_plugin: Add support for new MPIR PCI register.
- phy_diag_plugin: Send SLRG, SLRP, SLTP registers for PCI according to MPEIN.
- phy_diag_plugin: Send PCI counters diagnostic page for PCI according to MPEIN.
- phy_diag_plugin: net_dump_ext format changes.
- phy_diag_plugin:: Add SymbolErrorCounter to net_dump_ext.
- ibdm: Add ibnl file for Manta-Ray (CS8500).


### Fixes:

- ibdiagnet: fix sensor name dump in MTMP.
- phy_diag_plugin: Create net_dump_ext only when get_phy_info is enabled.


### Changes:

- ibdiagnet: Update possible_sections.txt file.
- ibdiagnet: Remove mlx_lossy from spec file.
- ibdiagnet: Skip on ANs in credit loop.
- ibdiagnet: Show help for plugins by default.
- phy_diag_plugin: Change format for net_dump_ext file.
- phy_diag_plugin: Update help message that get_p_info is for PCI.
- ibis: Enable mlx_lossy only if infiniband/mad.h exist.
- ibis: Support compilation on rdma-core.
- ibis: Add new API of diagnostic data mad get info and set clear.
- ibis: Add flag to compile mlx_lossy.


### Known issues

- ibdiagnet: When running with **-o &lt;path&gt;** option, ibdiagnet writes temporary log file at /var/tmp/ibdiagnet2.log instead of at the specified path.
- ibdiagnet: VL rate limits of virtual ports is not supported.
- ibdiagnet: Shows information of disconnected ports in net_dump_ext.

